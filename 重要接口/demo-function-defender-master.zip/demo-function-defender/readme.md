# 拦截函数执行

 开启安全配置

![1](screenshots/safe1.png)

拦截效果

![2](screenshots/safe2.png)
