package com.fr.security.function;

import com.fr.plugin.context.PluginContext;
import com.fr.plugin.observer.inner.AbstractPluginLifecycleMonitor;
import com.fr.security.function.conf.RemoteEvalConfig;

/**
 * @author richie
 * @version 10.0
 * Created by richie on 2019-01-12
 */
public class RemoteEvalInitializeMonitor extends AbstractPluginLifecycleMonitor {
    @Override
    public void afterRun(PluginContext context) {
        RemoteEvalConfig.getInstance();
    }

    @Override
    public void beforeStop(PluginContext context) {

    }
}
