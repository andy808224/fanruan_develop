package com.fr.security.function.conf;

import com.fr.config.ConfigContext;
import com.fr.config.DefaultConfiguration;
import com.fr.config.Identifier;
import com.fr.config.Status;
import com.fr.config.Visualization;
import com.fr.config.holder.Conf;
import com.fr.config.holder.factory.Holders;
import com.fr.stable.StringUtils;

/**
 * @author richie
 * @version 10.0
 * Created by richie on 2019-01-12
 */
@Visualization(category = "Plugin-Security")
public class RemoteEvalConfig extends DefaultConfiguration {

    private static volatile RemoteEvalConfig config = null;

    public static RemoteEvalConfig getInstance() {
        if (config == null) {
            config = ConfigContext.getConfigInstance(RemoteEvalConfig.class);
        }
        return config;
    }

    @Identifier(value = "enable", name = "Plugin-Remote_Eval_Restrict", description = "Plugin-Remote_Eval_Restrict_Description", status = Status.SHOW)
    private Conf<Boolean> enable = Holders.simple(true);

    @Identifier(value = "text", name = "Plugin-Remote_Eval_Restrict_Text", description = "Plugin-Remote_Eval_Restrict_Text_Description", status = Status.SHOW)
    private Conf<String> text = Holders.simple(StringUtils.EMPTY);

    @Identifier(value = "signatureText", name = "Plugin-Remote_Signature_Key", description = "Plugin-Remote_Signature_Key", status = Status.SHOW)
    private Conf<String> signatureText = Holders.simple(StringUtils.EMPTY);

    public boolean isEnable() {
        return enable.get();
    }

    public void setEnable(boolean enable) {
        this.enable.set(enable);
    }

    public String getText() {
        return text.get();
    }

    public void setText(String text) {
        this.text.set(text);
    }

    public String getSignatureText() {
        return signatureText.get();
    }

    public void setSignatureText(String signatureText) {
        this.signatureText.set(signatureText);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        RemoteEvalConfig cloned = (RemoteEvalConfig) super.clone();
        cloned.enable = (Conf<Boolean>) enable.clone();
        cloned.text = (Conf<String>) text.clone();
        cloned.signatureText = (Conf<String>) signatureText.clone();
        return cloned;
    }
}
