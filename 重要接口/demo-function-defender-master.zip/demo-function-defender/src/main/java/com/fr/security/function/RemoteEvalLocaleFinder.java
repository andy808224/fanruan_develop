package com.fr.security.function;

import com.fr.stable.fun.impl.AbstractLocaleFinder;

/**
 * @author richie
 * @version 10.0
 * Created by richie on 2019-01-12
 */
public class RemoteEvalLocaleFinder extends AbstractLocaleFinder {
    @Override
    public String find() {
        return "com/fr/security/function/ref";
    }
}
