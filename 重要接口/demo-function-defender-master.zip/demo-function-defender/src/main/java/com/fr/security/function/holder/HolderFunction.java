package com.fr.security.function.holder;

import com.fr.script.AbstractFunction;
import com.fr.security.function.conf.RemoteEvalConfig;
import com.fr.stable.StringUtils;

/**
 * @author richie
 * @version 10.0
 * Created by richie on 2019-01-12
 */
public class HolderFunction extends AbstractFunction {

    public static final HolderFunction ONE = new HolderFunction();

    private HolderFunction() {

    }

    @Override
    public Object run(Object[] args) {
        String text = RemoteEvalConfig.getInstance().getText();
        if (StringUtils.isBlank(text)) {
            throw new IllegalStateException("FR.remoteEvaluate cannot call this formula because of safety.");
        } else {
            return text;
        }
    }
}
