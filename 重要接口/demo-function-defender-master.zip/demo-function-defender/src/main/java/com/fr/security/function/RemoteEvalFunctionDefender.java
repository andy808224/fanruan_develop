package com.fr.security.function;

import com.fr.intelli.record.Focus;
import com.fr.record.analyzer.EnableMetrics;
import com.fr.security.function.conf.RemoteEvalConfig;
import com.fr.security.function.holder.HolderFunction;
import com.fr.stable.fun.impl.AbstractFunctionDefendProvider;
import com.fr.stable.script.CalculatorProvider;
import com.fr.stable.script.Function;

import java.lang.annotation.Annotation;

/**
 * @author richie
 * @version 10.0
 * Created by richie on 2019-01-12
 */
@EnableMetrics
public class RemoteEvalFunctionDefender extends AbstractFunctionDefendProvider {

    @Override
    @Focus(id = "com.fr.security.function", text = "defender")
    public Function replacer(CalculatorProvider calculator, Class clazz) {
        return HolderFunction.ONE;
    }

    @Override
    public boolean match(CalculatorProvider calculator, Class clazz) {
        if (RemoteEvalConfig.getInstance().isEnable()) {
            Boolean mark = calculator.getAttribute(RestrictScriptKey.KEY);
            if (mark != null && mark) {
                Annotation restrict = clazz.getAnnotation(RestrictScript.class);
                return restrict != null;
            }
        }
        return false;
    }
}
