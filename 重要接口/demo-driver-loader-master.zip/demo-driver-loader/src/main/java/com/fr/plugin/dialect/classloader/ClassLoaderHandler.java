package com.fr.plugin.dialect.classloader;


import com.fr.intelli.record.Focus;
import com.fr.intelli.record.Original;
import com.fr.io.utils.ResourceIOUtils;
import com.fr.log.FineLoggerFactory;
import com.fr.record.analyzer.EnableMetrics;
import com.fr.stable.fun.impl.AbstractDataSourceDriverLoader;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Munin on 2019/5/20
 */

@EnableMetrics
public class ClassLoaderHandler extends AbstractDataSourceDriverLoader {
    private ClassLoader driverClassLoader;
    //插件获取jar的路径，和lib同级的driverlib目录
    public static final String DRIVER_LIB_DIR = "driverlib";

    //demo设置为hive为目标驱动
    private static final String DRIVER_NAME_KEY = "org.apache.hive.jdbc.HiveDriver";

    @Focus(id = "com.fr.plugin.dialect.classloader.ClassLoaderHandler", text = "", source = Original.PLUGIN)
    public boolean isInterceptAllowed(String driverName) {
        if (driverName == null) {
            FineLoggerFactory.getLogger().error("error driver name");
            return false;
        }
        if (driverName.equals(DRIVER_NAME_KEY)) {
            FineLoggerFactory.getLogger().info("correct driver name");
            return true;
        }
        return false;
    }

    @Focus(id = "com.fr.plugin.dialect.classloader.ClassLoaderHandler", text = "", source = Original.PLUGIN)
    public ClassLoader getClassLoader() {
        FineLoggerFactory.getLogger().info("====== Loading Hive ClassLoader ... ======");
        synchronized (this) {
            if (this.driverClassLoader == null) {
                URL[] urls = getJarURLS();
                this.driverClassLoader = new DriverClassLoader(urls);
            }
            return driverClassLoader;
        }
    }


    public URL[] getJarURLS() {
        List<URL> libUrls = new ArrayList<URL>();
        try {

            String dir = ResourceIOUtils.getRealPath(DRIVER_LIB_DIR);
            File parentDir = new File(dir);
            File[] files = parentDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    try {
                        libUrls.add(file.toURI().toURL());
                    } catch (MalformedURLException e) {
                        FineLoggerFactory.getLogger().warn("get JAR URLS error, the driver lib path is:{}", dir);
                    }

                }
            }
        } catch (Exception e) {
        }

        return libUrls.toArray(new URL[0]);
    }
}
