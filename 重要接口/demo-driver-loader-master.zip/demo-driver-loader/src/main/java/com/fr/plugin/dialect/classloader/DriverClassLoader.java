package com.fr.plugin.dialect.classloader;

import com.fr.log.FineLoggerFactory;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author: Roy
 * @date: 2019/5/29 6:39 PM
 */
public class DriverClassLoader extends URLClassLoader {

    public DriverClassLoader(URL[] urls) {
        super(urls, Thread.currentThread().getContextClassLoader());
    }


    @Override
    public Class<?> loadClass(String name) throws ClassNotFoundException {
        synchronized (getClassLoadingLock(name)) {
            Class<?> c = findLoadedClass(name);
            if (c == null) {
                try {
                    c = findClass(name);
                    FineLoggerFactory.getLogger().debug("load class {} from driverlib successful", name);
                } catch (Exception e) {
                    //can not find class in isolate dir, try to load from common lib
                }
            }

            if (c == null) {
                FineLoggerFactory.getLogger().debug("Did not find class{}, in the paths {}, try to get from common lib", name, this.getUrlStrings());
                c = super.loadClass(name);
            }
            return c;

        }

    }

    private String getUrlStrings() {
        StringBuilder stringBuilder = new StringBuilder();
        try {

            for (URL url : getURLs()) {
                stringBuilder
                        .append("\n\r")
                        .append(url.getPath())
                        .append("\n\r");
            }

        } catch (Exception e) {

        }
        return stringBuilder.toString();
    }
}
