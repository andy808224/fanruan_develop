# demo-driver-loader

特定驱动的ClassLoader拦截器demo

使用方法：

 该插件是用于隔离数据库JDBC的驱动jar包，从而避免驱动jar引入的jar包冲突问题
 
 启用该插件以后，需要在WEB-INF目录下新建一个driverlib文件夹，将对应的驱动jar包放入这个文件夹内即可
 
 注意A：使用了隔离插件以后驱动jar包不需要放在lib目录下
 注意B：HIVE驱动依赖于slf4j的jar，同样需要放入dirverlib文件夹中
 
 目前该插件默认是隔离MySQL的驱动，如果是其他数据源，只需要修改DRIVER_NAME_KEY为对应的驱动即可

PS：demo需要依赖最新release分支的datasource模块

